// Spinner animation - Shows spinning animation when user clicks "load more"

import React from 'react';

const Spinner = () => {
    return (
        <div className="loader"></div>
    )
}

export default Spinner;